# -*- coding: utf-8 -*-
#

"""
Fichier permettant de tester de façon systématique le bon fonctionnement des librairies 
"""

from graphique import *
from entree_tk import *
from lycee import *

"""
Les fonctions de lycee
"""
print('\n Les fonctions de lycee')
# arithmetique
print('pgcd(12,4) =',pgcd(12,4))
print('pgcd(-4,12) = ',pgcd(-4,12))

print('reste(15,4) = ',reste(15,4))

print('quotient(15,4) = ',quotient(15,4))

# fonctions usuelles

print('4**1/2 = ',puissance(4,1/2))
print('2**-2 = ',puissance(2,-2))

print('carre =  ',carre(-2))

print('racine de 4 = ',racine(4))

print('4! = ',factoriel(4))

print('Partie entière de -2,5 = ',partie_entiere(-2.5))
print('Sans virgule = ',sans_virgule(-2.5))

print('exp(1) = ',exp(1))
print('ln(e) = ', ln(exp(1)))
print('log(10) = ' ,log(10))

# stats_proba

# Reste à faire

# chaines
print('\n Les fonctions sur les chaines')
print('la fonction taille doit afficher 2 : ',taille('ab'))
print('la fonction taille doit afficher 3 : ' ,taille([0,1,2]))

chaine2fich('Yo !', 'blabla')
print('Allez voir dans votre répertoire courant doit avoir un fichier blabla qui contient Yo !')

contenu=fich2chaine()
print('La machine doit vous dire bonjour...')
print('Machine : ',contenu)

# listes
print('\n Les fonctions sur les listes à partir de fichier')

print('On doit avoir une liste de 0 à 9 : ',CSV2liste('A','TableurPourTest.csv'))
print('On doit avoir une liste de 10 en 10 : ',CSV2liste(1,'TableurPourTest.csv'))

liste2CSV([1,'a',3,'bonjour',10,'aurevoir'], fichier='TableurPourTest2.csv')
print('Votre répertoire courant doit contenir un fichier TableurPourTest2.csv')

print(affiche_poly([1,1,1]))

"""
Les fonctions de entre_tk
"""
print('\n Les fonctions de entre_tk')
nom = demander_texte('Bonjour', "Quel est ton nom?")

age = demander_reel("Quel age as tu?")

"""
Les fonctions de graphiques
"""
print('\n Les fonctions de graphique')
annee = str(int(2019 - age))

creer_fenetre()
trace_texte(-5, 5, nom + " est né(e) en " + annee)

trace_point(5, 3)
trace_segment(-10, -4, 8, 7, couleur='red', taille = 2)
trace_rectangle(1, 1, 8, 4, couleur='black', taille = 4, remplissage='yellow')
trace_point(5, 5, couleur='blue',taille=5)
trace_point(6, 7, couleur='blue', taille=5, forme='croix')

    
affiche_fenetre()
