# -*- coding: utf-8 -*-
#

"""
brouillon de librairie graphique dynamique utilisant pygame.
"""

# import des librairies
import pygame
import sys
import math
from vecteur import *

# Definition couleur RGB
blanc = (255, 255, 255)
bleu = (0, 0, 255)
vert = (0, 255, 0)
rouge = (255, 0, 0)
noir = (0, 0, 0)


def creer_fenetre(largeur=200, hauteur=300, titre="Fenetre graphique"):
    """
    Crée et affiche une fenêtre graphique.

    Arguments:
        largeur (int, optionel): Largeur de la fenetre en pixels (``200`` par défaut)
        hauteur (int, optionel): Hauteur de la fenetre en pixels (``300`` par défaut)
        titre (str, optionel): Titre de la fenetre (``Fenetre graphique`` par défaut)
    """

    pygame.init()
    global fenetre
    fenetre = pygame.display.set_mode((largeur, hauteur))
    pygame.display.set_caption(titre)
    fenetre.fill(blanc)


def evenements():
    """
    Récupère les évenements pygame et gère la fermeture de la fenetre.

    Returns:
        Liste des évenements pygame https://www.pygame.org/docs/ref/event.html#pygame.event.get
    """
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT: sys.exit()
    return events


def trace_cercle(x, y, rayon=5, epaisseur=0, couleur=bleu):
    """
    Trace un cercle dans la fenetre graphique.

    Arguments:
        x (float): Abscisse du centre du cercle
        y (float): Ordonnée du centre du cercle
        rayon (float, optionel): Rayon du cercle (5 par défaut)
        epaisseur (float, optionel): Epaisseur du cercle (``0`` par défaut). Si `0`, le cercle sera rempli et apparaitra comme un disque.
        couleur (?, optionnel): Couleur du cercle (bleu par défaut)
    """
    pygame.draw.circle(fenetre, couleur, (x,y), rayon, epaisseur)
    pygame.display.update()


def trace_point(x, y, couleur=bleu):
    """
    Trace un point dans la fenetre graphique.

    Arguments:
        x (float): Abscisse du point
        y (float): Ordonnée du point
        couleur (?, optionnel): Couleur du point (bleu par défaut)
    """
    pygame.draw.circle(fenetre, couleur, (x,y), 1, 0)
    pygame.display.update()


def trace_rectangle(x, y, largeur, hauteur, couleur=bleu, epaisseur=1):
    """
    Trace un rectangle dans la fenetre graphique.
    (x,y) _______________
         |               |
         |               | hauteur
         |_______________|
              largeur
    Arguments:
        x (float): abscisse du sommet haut gauche du rectangle
        y (float): ordonnée du sommet haut gauche du rectangle
        largeur (float): taille du rectangle sur l'axe des abscisses
        hauteur (float): taille du rectangle sur l'axe des ordonnées
        couleur (?, optionnel): Couleur du rectangle (``bleu`` par défaut)
        epaisseur (int, optionnel): Epaisseur des cotés du rectangle (``1`` par défaut). Si ``0``, le rectangle est rempli.

    """

    pygame.draw.rect(fenetre, couleur, (x, y, largeur, hauteur), epaisseur)
    pygame.display.update()


def trace_segment(x1, y1, x2, y2, couleur=bleu, epaisseur=1):
    """
    Trace un segment entre les points de coordonées ``(x1, y1)`` et ``(x2, y2)``.

    Arguments:
        x1 (float): abscisse de la première extremité du segment
        y1 (float): ordonnée de la première extremité du segment
        x2 (float): abscisse de la deuxieme extrémité du segment
        y2 (float): ordonnée de la deuxieme extrémité du segment
        couleur (?, optionel): Couleur du segment (``bleu`` par défaut)
        epaisseur (float, optionel): Epaisseur du segment (``1`` par défaut)
    """
    pygame.draw.lines(fenetre, couleur, False, [(x1, y1), (x2, y2)], epaisseur)
 
def trace_vecteur(x, y, v, couleur=rouge, epaisseur=2):
	"""
    Trace la représentation du vecteur ``v`` à partir du point d'origine ``(x, y)``.

    Arguments:
        x (float): abscisse du point d'origine de la représentation du vecteur
        y (float): ordonnée du point d'origine de la représentation du vecteur
        v (array): abscisse de la deuxieme extrémité du segment
        couleur (?, optionel): Couleur du segment (``rouge`` par défaut)
        epaisseur (float, optionel): Epaisseur du segment (``1`` par défaut)
    """
    trace_segment(x, y,x+v[0], y+v[1],couleur, epaisseur)
    w1=-.3*math.cos(15*math.pi/180)* v +.3*math.sin(15*math.pi/180)*vecteur(-v[1],v[0])
    w2=-.3*math.cos(15*math.pi/180)* v -.3*math.sin(15*math.pi/180)*vecteur(-v[1],v[0])
	pygame.draw.polygon(fenetre, couleur, [(x+v[0], y+v[1]),(x+v[0]+w1[0], y+v[1]+w1[1]),(x+v[0]+w2[0], y+v[1]+w2[1]),(x+v[0], y+[1])], 0)
