# -*- coding: utf-8 -*-
"""
Partie statistiques et probobilité du module lycee.
"""
"""
Créé à partir d' Edupython: http://edupython.tuxfamily.org/

Licence CECILL http://www.cecill.info/
"""

import math
import builtins
from scipy.stats import norm
from arithmetique import quotient
import matplotlib.pyplot as repere
import random


def binomial(n, p):
    """
    Renvoie un entier (int) représentant le coefficient binomial ``p`` parmi ``n``.

    C'est à dire le nombre de chemins de l’arbre réalisant ``p`` succès pour ``n`` répétitions.

    Arguments:
        n (int): Un nombre entier
        p (int): Un nombre entier
    """
    if p <= n:
        return quotient(
            math.factorial(n),
            math.factorial(p) * math.factorial(p)
        )
    else:
        return 0


def tirage_binomial(n, p):
    """
    Renvoie un nombre entier (int) choisi de manière aléatoire selon une loi binomiale B(n,p) : ``p`` parmi ``ǹ``.

    Arguments:
        n (int): Premier paramètre de la loi binomiale à simuler.
        p (int): Second paramètre de la loi binomiale à simuler.
    """
    s = 0
    for i in range(n):
        if alea() < p:
            s = s + 1
    return s


def alea_entier(min, max):
    """
    Renvoie un entier (int) choisi de manière (pseudo)aléatoire et équiprobable
    dans l'intervalle [``min`` ; ``max``].

    Arguments:
        min (int): Un nombre entier
        max (int): Un nombre entier
    """
    return random.randint(min, max)


def choix(liste):
    """
    Renvoie un élément de la liste ``liste`` choisi (pseudo)aléatoirement et de manière équipropable

    Arguments:
        liste (int): La liste dans laquelle on choisit un élément.
    """
    return random.choice(liste)


def alea():
    """
    Renvoie au hasard un décimal de l'intervalle [0 ; 1[
    """
    return random.random()


def expovariate(x):
    """
    Renvoie un nombre décimal (float) choisi de manière aléatoire selon
    une loi exponentielle de paramètre ``x``.

    Arguments:
        x (float) : est un réel strictement positif.
    """
    return random.expovariate(x)


def gauss(mu, sigma):
    """
    Renvoie un nombre décimal (float) choisi de manière aléatoire
    selon une loi nomale d'espérance ``mu`` et d'écart type ``sigma``.

    Arguments:
        mu (float): Un nombre décimal. L'éspérance de la loi normale
        sigma (float): Un nombre décimal. L'écart type de la loi normale
    """
    return random.gauss(mu, sigma)


def normal_frep(a, b, mu, sigma):
    """
    Renvoie un nombre décimal (float) représentant une estimation de la probobilité P(``a`` < X < ``b``)
    lorsque X suit une loi normale d'espérance ``mu`` et d'écart type ``sigma``.

    Arguments:
        a (float): Un nombre décimal
        b (float): Un nombre décimal
        mu (float): Un nombre décimal. L'éspérance de la loi normale
        sigma (float): Un nombre décimal. L'écart type de la loi normale
    """
    if a < b:
        return norm.cdf(b, mu, sigma) - norm.cdf(a, mu, sigma)
    else:
        return 0


def inv_norm(k, mu, sigma):
    """
    Renvoie la valeur du réel x (float) telle que  P(X < x) = ``k``
    lorsque X suit une loi normale d'espérance ``mu`` et d'écart type ``sigma``.

    Arguments:
        k (float): Un nombre décimal
        mu (float): Un nombre décimal. L'éspérance de la loi normale
        sigma (float): Un nombre décimal. L'écart type de la loi normale
    """
    return norm.ppf(k, mu, sigma)


def uniforme(min, max):
    """
    Renvoie un nombre décimal (float) choisi de manière (pseudo)aléatoire et uniforme
    de l'intervalle \[``min`` ; ``max``\[.

    Arguments:
        min (float): Un nombre réel.
        max (float): Un nombre réel.

    """
    return random.uniform(min, max)


def intervalle(debut, fin, pas=1):
    """
    Renvoie une liste d’entiers de ``deb`` à ``fin`` avec un pas de ``pas``.

    Arguments:
        deb (int): Le début de l'intervalle
        fin (int): La fin de l'intervalle
        pas (int, optionnel): Le pas (``1`` par défaut).
    """
    return builtins.range(debut, fin + 1, pas)


def baton(xi, ni='optionnel', couleur='b'):
    """
    Génére le diagramme en bâtons relatif à la liste ``xi``.

    Arguments:
        xi (list): liste de valeurs que l'on veut représenter
        ni (list, optionnel): liste des effectifs associés.
        couleur (str, optionnel):  la couleur du diagramme (bleue par défaut)
    """

    if not isinstance(ni, list):
        xi, ni = compte(xi, 'effectif')
    repere.title('Diagramme en bâtons de la liste')
    repere.ylabel('Effectifs')
    repere.xlabel('Valeurs de la liste')
    for i in range(len(xi)):
        repere.plot([xi[i], xi[i]], [0, ni[i]], couleur, lw=2)
    repere.axis([min(xi) - 0.1, max(xi) + 0.1, 0, max(ni)])


def histop(Liste, Classes='optionnel'):  # Majuscule sur une variable est mauvais style.
    """
    Génère l'histogramme relatif à la liste ``Liste`` d'aire totale 1.

    Si seul l'argument  ``Liste`` est renseigné, les valeurs seront réparties en 10 classes.
    Si Classes est un entier, les valeurs seront réparties en ce nombre de classes.
    Sinon, vous pouvez choisir vos classes d'amplitudes variées
    en indiquant comme ``Classes``, la liste ordonnée des bornes.

    Arguments:
        Liste (list): Une liste de valeurs
        Classes (int ou list, optionnel): voir ci dessus
    """
    C = Classes
    if C == 'optionnel':
        C = 10
    if isinstance(C, int):
        pas = (max(Liste) - min(Liste)) / C
        a = min(Liste)
        C = []
        while a <= max(Liste):
            C.append(a)
            a = a + pas
    Eff = [0] * (len(C) - 1)
    for v in Liste:
        i = 0
        while i < len(C) - 1:
            if v >= C[i] and (
                    v < C[i + 1] or (i == len(C) - 2 and v == C[i + 1])):
                Eff[i] = Eff[i] + 1
                i = len(C)
            else:
                i = i + 1
    taille = [C[i + 1] - C[i] for i in range(len(C) - 1)]
    TotalEff = sum(Eff)
    H = [Eff[i] / (taille[i] * TotalEff) for i in range(len(C) - 1)]
    repere.bar(C[:-1], H, width=taille)
    n = int(len(Liste) / (len(C) - 1) / 5)
    if n == 0:
        n = 1
    if n > 9:
        d = int(math.ln(n) / math.ln(10)) - 1
        n = int(round(n * (10**(-d)))) * 10**d
    xi, ni = compte(taille, 'effectif')
    m = max(ni)
    l, i = 0, 0
    while l == 0:
        if ni[i] == m:
            l = xi[i]
        else:
            i = i + 1
    for i in range(len(taille)):
        if taille[i] == l and Eff[i] != 0:
            h = H[i] * n / Eff[i]
    xc = C[0]
    yc = max(H) * 1.1
    repere.plot([xc, xc + l], [yc, yc], 'b')
    repere.plot([xc, xc + l], [yc + h, yc + h], 'b')
    repere.plot([xc, xc], [yc, yc + h], 'b')
    repere.plot([xc + l, xc + l], [yc, yc + h], 'b')
    txt = " " + str(n) + " individu"
    if n > 1:
        txt = txt + "s"
    txt = txt + ", soit " + \
        str(round(n / len(Liste) * 10000) / 100) + "% de la population"
    repere.text(xc + l * 1.1, yc + h / 2, txt, verticalalignment='center')


def barre(Liste, a='optionnel', pas='optionnel'):  # à refaire, c'est confus
    """
    Génère le diagramme en barres relatif à la liste ``Liste``.

    Si seulement ``Liste`` est renseigné, les valeurs seront réparties en 10 classes.
    Si ``Liste`` et ``a`` sont renseignés, les valeurs seront réparties en ``a`` classes.
    Si les trois paramètres sont renseignés:
    - ``a`` est le centre de la première classe,
    - et ``pas`` est l'amplitude des classes.

    Arguments:
        Liste (list): liste de valeurs
        a (float, optionel): le centre de la première classe ou le nombre de classes
        pas (float, optionel): l'amplitude des classes.
    """
    if pas == 'optionnel':
        if a == 'optionnel':
            a = 10
        repere.hist(Liste, bins=a)
    else:
        n = a - pas / 2
        C = []
        while n < max(Liste) + pas:
            C.append(n)
            n = n + pas
        Eff = [0] * (len(C) - 1)
        for v in Liste:
            i = 0
            while i < len(C) - 1:
                if v >= C[i] and v < C[i +
                                       1] or (i == len(C) - 2 and v == C[i + 1]):
                    Eff[i] = Eff[i] + 1
                    i = len(C)
                else:
                    i = i + 1
        repere.bar(C[:-1], Eff, width=pas)


def compte(liste, option='optionnel'):
    """
    Retourne la liste triée sans les doublons et
    – Si l'option est "effectif", la liste est retournée avec les effectifs des valeurs.
    – Si l'option est "frequence", la liste est retournée avec les fréquences des valeurs.

    Arguments:
        liste (list): une liste de nombres
        option (str, optionnel): "frequence" ou "effectif"
    """
    def divliste(x):  # Définition de la fonction pour diviser par l'effectif total
        return x / len(liste)
    # On trie la liste pour rencontrer les éléments par ordre croissant.
    liste = sorted(liste)
    # Initialise la liste des valeurs avec la première valeur
    listf = [liste[0]]
    # Initialise la liste des effectifs avec le premier effectif associé
    eff = [liste.count(liste[0])]
    for i in range(len(liste)):  # On parcourt la série
        if liste[i] not in listf:
            # Si l'élément n'a pas encore été rencontré, il est ajouté à la
            # liste.
            listf.append(liste[i])
            # Ajoute à la liste des effectifs, l'effectif associé à cette
            # nouvelle valeur
            eff.append(liste.count(liste[i]))
    if option == 'effectif':
        return sorted(listf), eff
    elif option == 'frequence' or option == 'frequences':
        # Calcul des fréquences par division par l'effectif total.
        return sorted(listf), list(map(divliste, eff))
    else:
        return sorted(listf)


def centres(L):  # Pourquoi?
    """
    Renvoie une liste de longueur n-1 contenant les valeurs (L[i]+L[i+1])/2.

    Arguments:
        L (list): Une liste de taille n
    """
    R = []
    for i in range(len(L) - 1):
        R.append((L[i] + L[i + 1]) / 2)
    return R


def ECC(xi, ni='optionnel'):
    """
    Génère les effectifs cumulés croissants de la liste ``xi``.

    Arguments:
        xi (list): liste de valeurs
        ni (list, optionnel): liste des effectifs associés
    """
    if ni == 'optionnel':
        xi, ni = compte(xi, 'effectif')
    T = 0
    E = []
    for i in range(len(ni)):
        T = T + ni[i]
        E.append(T)
    return xi, E


def FCC(xi, ni='optionnel'):
    """
    Génère les fréquences cumulées croissantes de la liste ``xi``.

    Arguments:
        xi (list): Une liste de valeurs
        ni (list, optionnel): La liste des effectifs associés
    """
    xi, ni = ECC(xi, ni)
    for i in range(len(ni)):
        ni[i] = ni[i] / ni[len(ni) - 1]
    return xi, ni


def polygoneECC(xi, ni='optionnel', couleur='b'):
    """
    Génére le polygone des Effectifs Cumulés Croissants de la liste.

    Arguments:
        xi (list): une liste de valeurs
        ni (list, optionel): la liste des effectifs associés.
        couleur (str, optionnel): couleur du polygone ('b'=bleue par défaut)

    """
    xi, ec = ECC(xi, ni)
    if len(xi) == len(ec) + 1:
        ec.insert(0, 0)
        repere.plot(xi, ec, couleur + 'o')
        repere.plot(xi, ec, couleur)
        repere.title('Polygone des Effectifs Cumules Croissants')
        repere.ylabel('Effectifs')
        repere.xlabel('Valeurs de la liste')


def polygoneFCC(xi, ni='optionnel', couleur='b'):
    """
    Génére le polygone des fréquences cumulées croissantes de la liste ``xi``.

    Arguments:
        xi (list): liste de valeurs.
        ni (list, optionnel): liste des effectifs
        couleur (str, optionnel): couleur de graphique ('b'=bleue par défaut)
    """
    xi, ec = FCC(xi, ni)
    if len(xi) == len(ec) + 1:
        ec.insert(0, 0)
        repere.plot(xi, ec, couleur + 'o')
        repere.plot(xi, ec, couleur)
        repere.title("Polygone des Frequences Cumulees Croissantes")
        repere.ylabel('Frequences')
        repere.xlabel('Valeurs de la liste')


def moyenne(xi, ni='optionnel'):
    """
    Renvoie la moyenne de la liste ``xi``.

    Arguments:
        xi (list): liste de valeurs (ou les extrémité des classes)
        ni (liste, optionnel): série des effectifs associés
    """
    if ni == 'optionnel':
        xi, ni = compte(xi, 'effectif')
    if len(xi) == len(ni) + 1:
        xi = centres(xi)  # Si on travaille avec des classes
    s = 0
    # print xi,ni
    for i in range(len(xi)):
        s = s + xi[i] * ni[i]
    return s / sum(ni)

# Les fonctions suivantes utilisent un fonction mistérieuse trier_liste.

# def mediane(xi, ni='optionnel', option='optionel'):  # confus, à refaire
#     """
#     Renvoie la médiane de la liste ``xi``.
#
#     - L'option par défaut est l'option 1.
#     - Si l'option est 1, la médiane est la valeur centrale (valeur de la série ou moyenne arithmétique)
#     - Si l'option est 2, la médiane est la valeur pour laquelle on dépasse 50% des valeurs.
#
#     Arguments:
#         xi (list): Liste de valeurs
#         ni (list, optionel): Liste des effectifs associés
#         option (int, optionel):  1 ou 2
#     """
#     if ni == 'optionnel':  # On vérifie si ni existe
#         xi, ni = compte(xi, 'effectif')
#     elif ni == 2 or ni == 1:  # On vérifie si option existe
#         option = ni
#         xi, ni = compte(xi, 'effectif')
#     else:  # ni existe, on vérifie si xi est ordonnée sinon on trie xi et ni
#         if xi != sorted(xi) and isinstance(ni, list):
#             xi, ni = trier_liste(xi, ni)
#     i = 0
#     k = ni[0]
#     while k < sum(ni) / 2:
#         i = i + 1
#         k = k + ni[i]
#     if option == 2:  # Option 2
#         if k <= sum(ni) / 2:
#             return xi[i + 1]
#         else:
#             return xi[i]
#     else:  # Option 1 par défaut
#         if sum(ni) / 2 == int(sum(ni) / 2):
#             if k <= sum(ni) / 2:
#                 return (xi[i] + xi[i + 1]) / 2
#             else:
#                 return xi[i]
#         else:
#             if k <= sum(ni) / 2:
#                 return xi[i + 1]
#             else:
#                 return xi[i]
#
#
# def quartile(xi, ni='optionnel', valeur='optionnel'):  # confus, il est plus simple de retourner une liste de 3 valeurs
#     """
#     Retourne les quartiles de la liste.
#
#     - Si valeur=1, retourne le premier quartile.
#     - Si valeur=3, retourne le troisième quartile.
#     - Par défaut, le premier et le troisième quartile sont retournés
#
#     Arguments:
#         xi (list): Une série de valeurs
#         ni (list, optionel): Liste des effectifs associés
#         valeur (int, optionel):  le quartile que l'on souhaite 1 ou 3
#     """
#     if ni == 'optionnel':  # On vérifie si ni existe
#         xi, ni = compte(xi, 'effectif')
#     elif ni == 3 or ni == 1:  # On vérifie si valeur existe
#         valeur = ni
#         xi, ni = compte(xi, 'effectif')
#     else:  # ni existe, on vérifie si xi est ordonnée sinon on trie xi et ni
#         if xi != sorted(xi) and isinstance(ni, list):
#             xi, ni = trier_liste(xi, ni)
#     q1pos = int(sum(ni) / 4)  # On définit la position de q1
#     q3pos = int(3 * sum(ni) / 4)  # On définit la position de q3
#     k = 0
#     i = 0
#     while k < q1pos:  # On cherche q1
#         k = k + ni[i]
#         i = i + 1
#     q1 = xi[i]  # On définit q1
#     while k < q3pos:  # On cherche q3
#         k = k + ni[i]
#         i = i + 1
#     q3 = xi[i]  # On définit q3
#     if valeur == 1:  # Affichage du 1er quartile
#         return q1
#     if valeur == 3:  # Affichage du 3ème quartile
#         return q3
#     if valeur != 1 and valeur != 3:  # Option par défaut
#         return q1, q3
#
#     q1 = xi[int(len(xi) / 4)]  # c'est quoi ca?
#     q3 = xi[int(3 * len(xi) / 4)]
#     if valeur == 1:
#         return q1
#     elif valeur == 3:
#         return q3
#     else:
#         return q1, q3
#
#
# def decile(xi, ni='optionnel', valeur='optionnel'):  # Idem retourner une liste de 9 valeurs
#     """
#     Retourne les déciles de la liste.
#
#     - Si valeur=1, retourne le premier décile.
#     - Si valeur=9, retourne le neuvième décile.
#     - Par défaut, le premier et le neuvième décile sont retournés
#
#     Arguments:
#         xi (list): Liste de valeurs
#         ni (list, optionel): Liste des effectifs associés
#         valeur (int, optionel): le decile que l'on souhaite 1 ou 9
#     """
#     if ni == 'optionnel':  # On vérifie si ni existe
#         xi, ni = compte(xi, 'effectif')
#     elif ni == 9 or ni == 1:  # On vérifie si valeur existe
#         valeur = ni
#         xi, ni = compte(xi, 'effectif')
#     else:  # ni existe, on vérifie si xi est ordonnée sinon on trie xi et ni
#         if xi != sorted(xi) and isinstance(ni, list):
#             xi, ni = trier_liste(xi, ni)
#
#     d1pos = int(sum(ni) / 10)  # On définit la position de d1
#     d9pos = int(9 * sum(ni) / 10)  # On définit la position de d9
#     k = 0
#     i = 0
#     while k < d1pos:  # On cherche d1
#         k = k + ni[i]
#         i = i + 1
#     d1 = xi[i]  # On définit d1
#     while k < d9pos:  # On cherche d19
#         k = k + ni[i]
#         i = i + 1
#     d9 = xi[i]  # On définit d9
#     if valeur == 1:  # Affichage du 1er décile
#         return d1
#     if valeur == 9:  # Affichage du 9eme décile
#         return d9
#     if valeur != 1 and valeur != 9:  # Option par défaut
#         return d1, d9


def variance(xi, ni='optionnel'):
    """
    Retourne la variance de la liste.

    Arguments:
        xi (list): Liste de valeurs (ou les extrémité des classes)
        ni (list, optionnel): Liste des effectifs associés
    """
    if not isinstance(ni, list):
        xi, ni = compte(xi, 'effectif')
    if len(xi) == len(ni) + 1:
        xi = centres(xi)  # Si on travaille avec des classes
    v = 0
    xbar = moyenne(xi, ni)
    for i in range(len(xi)):
        v = v + (xi[i] - xbar)**2 * ni[i]
    return v / (sum(ni))


def ecartype(xi, ni='optionnel'):
    """
    Retourne l'écart-type de la liste.

    Arguments:
        xi (list): Liste de valeurs (ou les extrémité des classes)
        ni (list, optionnel): Liste des effectifs associés
    """
    return math.sqrt(variance(xi, ni))
