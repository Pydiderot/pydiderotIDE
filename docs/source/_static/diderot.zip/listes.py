"""
Partie listes du module lycee.
"""
"""
Créé à partir d' Edupython: http://edupython.tuxfamily.org/

Licence CECILL http://www.cecill.info/
"""

from chaines import fich2chaine, chaine2fich


def CSV2liste(num, fichier='optionel'):
    """
    Retourne une liste correspondant à la colonne ou la ligne nom du fichier ``fichier``.

    Si fichier n'est pas précisé, ouvre une boite de dialogue pour le choisir
    Le fichier ne doit contenir que des nombres et le séparateur doit être ``;``

    Arguments:
        num (str ou int): Un numéro de ligne ou un nom de colonne (``A`` à ``Z`` ).
        fichier (file,optionel): Le nom complet (avec le chemin) d'un fichier contenant des nombres.
    """
    ch = fich2chaine(fichier)
    if type(num) == int:
        L = ch.split("\n")
        if len(L) >= num:
            R = []
            for n in L[num - 1].split(";"):
                try:
                    R.append(eval(n))
                except:
                    raise Exception("Problème lors de l'importation")
            return R
    if type(num) == str:
        num = num.upper()
        c = ord(num) - ord('A')
        R = []
        for m1 in ch.split("\n"):
            m2 = m1.split(";")
            if len(m2) > c and m2[c] != '':
                try:
                    R.append(eval(m2[c].replace(' ', '').replace(',', '.')))
                except:
                    raise Exception("Problème lors de l'importation")
        return R

def liste2CSV(L, fichier='optionel'):
    """
    Enregistre sous le nom ``fichier`` la liste ``L``.

    Si fichier n'est pas précisé, ouvre une boite de dialogue pour le choisir

    Arguments:
        L (list): Une liste
        fichier (file, optionel): Le nom complet (avec le chemin) d'un fichier contenant du texte brut.
    """
    for i in range(len(L)):
        L[i] = str(L[i])
    chaine2fich("\n".join(L), fichier)
liste2CSV([1,'a',3,'bonjour',10,'aurevoir'], fichier='TableurPourTest2.csv')

def affiche_poly(L):  # Pourquoi???
    """
    Affiche la liste L sous forme d'un polynôme (L[n] étant le coefficient de degré n).

    Arguments:
        L (list): Une liste
    """
    poly = ""
    for i in range(len(L)):
        c = L[i]
        if c != 0 and poly != "":
            poly = poly + '+'
        if c != 0:
            if i > 0:
                if c == -1:
                    poly = poly + '-'
                if abs(c) != 1:
                    poly = poly + str(c)
            else:
                poly = poly + str(c)
            if i >0:
                poly = poly + 'X'
                if i > 1:
                    poly = poly + '^' + str(i)
    if poly == "":
        poly = 0
    return poly
